import pygame
import os
import random 
import time
import math
width = 1080
hight = 650
pygame.font.init()
win = pygame.display.set_mode((width, hight))
pygame.display.set_caption('Final Project by Abdul Hadi Adnan')

enemies = []
from pygame import mixer
pygame.mixer.init()
mixer.music.load('bg1.mp3')
mixer.music.play(-1)
destroy_sound = mixer.Sound('bomb.mp3')
hurt_sound = mixer.Sound('hurt.mp3')
#fire_sound = mixer.Sound('fire.mp3')

#loading images

enemy_ship1 = pygame.transform.scale(pygame.image.load(os.path.join('1.png')), (70,70))
bullet1 = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(os.path.join('1bullet.png')) , (70,70)),270)

enemy_ship2 = pygame.transform.scale(pygame.image.load(os.path.join('2.png')), (70,70))
bullet2= pygame.transform.rotate(pygame.transform.scale(pygame.image.load(os.path.join('2bullet.png')) , (70,70)),270)

enemy_ship3 = pygame.transform.scale(pygame.image.load(os.path.join('3.png')), (70,70))
bullet3 = pygame.transform.rotate(pygame.transform.scale(pygame.image.load(os.path.join('4.jpg')) , (70,70)),240)

player_ship = pygame.transform.scale(pygame.image.load(os.path.join('myship.png')), (70,70))
bullet = pygame.transform.scale(pygame.image.load(os.path.join('bullet.png')), (40,40))
bullet101 = pygame.transform.scale(pygame.image.load(os.path.join('bullet.png')), (120,120))

background = pygame.transform.scale(pygame.image.load(os.path.join('background.jpg')), (width,hight))
meteor_image = pygame.transform.scale(pygame.image.load(os.path.join('metro1.png')), (80,80))
meteor_image1 = pygame.transform.scale(pygame.image.load(os.path.join('metro2.png')), (90,90))
meteor_image2 = pygame.transform.scale(pygame.image.load(os.path.join('metro3.png')), (60,60))
meteor_image3 = pygame.transform.scale(pygame.image.load(os.path.join('metro4.png')), (90,90))

power1 = pygame.transform.scale(pygame.image.load(os.path.join('power1.png')), (30,30))
power2 = pygame.transform.scale(pygame.image.load(os.path.join('power2.png')), (30,30))
power3 = pygame.transform.scale(pygame.image.load(os.path.join('power3.png')), (30,30))

coin1 = pygame.transform.scale(pygame.image.load(os.path.join('coin1.png')), (30,30))
coin2 = pygame.transform.scale(pygame.image.load(os.path.join('coin2.png')), (30,30))
RED = (255,0,0)
sheild = 1
scoree = 0



all_meteor = []
all_powerups = []
all_score = []



class Bullet:
    def __init__(self, x,y,image):
        self.x = x
        self.y = y
        self.img = image
        self.mask = pygame.mask.from_surface(self.img)

    def draw(self, window):
        window.blit(self.img, (self.x - 7, self.y))

    def move(self, movement):
        self.y += movement
    def offscreen(self,hight):
        return not(self.y <= hight and self.y >= 0)
    def collision(self, i):
        
        return (collide(self, i))

        



class Ship:
    COOLDOWN = 30
    def __init__(self,x,y, health = 100):
        self.x = x
        self.y = y
        self.health = health
        self.ship_img = None
        self.bullet_img = None
        self.bullets = []
        self.cool_down = 0
       #pygame.draw.rect(window , (255,0,0), (self.x , self.y, 50 , 50))
    def draw(self, window):
        window.blit(self.ship_img, (self.x, self.y))
        for i in self.bullets:
            i.draw(window)
    def move_bullets(self, movement, obj):
        global sheild
        self.cooldown()
        for i in self.bullets:
            i.move(movement)
            if i.offscreen(hight):
                self.bullets.remove(i)
            elif i.collision(obj):
                if sheild > 0:
                    sheild -= 1
                else:
                    obj.health -= 10
                hurt_sound.play()
                self.bullets.remove(i)

    def cooldown(self):
        if self.cool_down >= self.COOLDOWN:
            self.cool_down = 0
        elif self.cool_down > 0:
            self.cool_down +=1

    def get_width(self):
        return self.ship_img.get_width()
    def get_hight(self):
        return self.ship_img.get_height()
    
    def shoot(self):
        
        if self.cool_down == 0:
            bulletp = Bullet(self.x + 25 ,self.y,self.bullet_img)  
            
            self.bullets.append(bulletp)
            
            self.cool_down += 1

    def removing_bullet(self):
        for i in self.bullets[:]:
            for t in enemies:
                if collide(i, t):
                    self.bullets.remove(i)
class score:
    global scoree
    def __init__(self):
        

        self.image = random.choice([coin1,coin2])
        self.rect = self.image.get_rect()
        self.x = random.randrange(width - self.rect.width)
        self.y = random.randrange(-2000, -400)
        self.mask = pygame.mask.from_surface(self.image)
    def update(self):
        self.y+=3
    def draw(self,window):
        window.blit(self.image, (self.x, self.y))
 
        
s = score()
all_score.append(s)
class powerup:
    def __init__(self):
        self.r = random.randrange(0,3)
        lit = [power1,power2,power3]
        self.image = lit[self.r]
        self.rect = self.image.get_rect()
        self.x = random.randrange(width - self.rect.width)
        self.y = random.randrange(-2000, -400)
        self.mask = pygame.mask.from_surface(self.image)
    def update(self):
        self.y+=1
    def draw(self,window):
        window.blit(self.image, (self.x, self.y))
  

u = powerup()
all_powerups.append(u)
class Meteor:
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = random.choice([meteor_image,meteor_image1,meteor_image2,meteor_image3])
        self.rect = self.image.get_rect()
        self.x = random.randrange(width - self.rect.width)
        self.y = random.randrange(-2000, -400)
        self.speedy = random.randrange(1, 6)
        self.mask = pygame.mask.from_surface(self.image)
        self.x2 = random.randrange(-2,4)
        
    def update(self):
        self.y += self.speedy
        self.x += self.x2
        if self.rect.top > hight + 10:
            self.x = random.randrange( width - self.width)
            self.y = random.randrange(-2000, -400)
    def draw(self,window):
        window.blit(self.image, (self.x , self.y))

    def boundary(self):
        if self.rect.right < 1 or self.rect.left > width+5:
            self.kill()
            m = Meteor()
            all_meteor.append(m)

m = Meteor()
all_meteor.append(m)
class Player(Ship):
    def __init__(self, x,y, health = 100):
        super().__init__(x,y, health)
        self.ship_img = player_ship
        self.bullet_img = bullet
        self.mask = pygame.mask.from_surface(self.ship_img)
        self.max_health = health

    def removeobj(self,objects,t):
        objects.remove(t)
        destroy_sound.play()
    def move_bullets(self,movement,objects):
        self.cooldown()
        for i in self.bullets:             
            i.move(movement)
            if i.offscreen(hight):
                self.bullets.remove(i)
            for t in objects:
                if i.collision(t):
                    objects.remove(t)
                    destroy_sound.play()
                    if i in self.bullets:
                        self.bullets.remove(i)
                 
    def reducehealth(self):
        self.health -= 10
        hurt_sound.play()
    def increasehealth(self):
        self.health += 30
    def draw(self,window):
        super().draw(window)
        
        self.healthbar(window)
        
    
    
    #health bar under player
    def healthbar(self, window):
        pygame.draw.rect(window, (255,0,0), (self.x, self.y + self.ship_img.get_height() + 10, self.ship_img.get_width(),  10))
        pygame.draw.rect(window, (0,255,0), (self.x, self.y + self.ship_img.get_height() + 10, self.ship_img.get_width() * (self.health/self.max_health), 10))
    def sheildbar(self,window):
        pygame.draw.rect(window, (0,0,255), (self.x, self.y + self.ship_img.get_height() + 5, self.ship_img.get_width(), 5))
        pygame.draw.rect(window, (0,255,0), (self.x, self.y + self.ship_img.get_height() + 5, self.ship_img.get_width() * (self.health/self.max_health), 5))
class Enemy(Ship):
    color_map = {
                'red' :(enemy_ship1,bullet1),
                'green':(enemy_ship2,bullet2),
                'blue':(enemy_ship3,bullet3)
                }

    def __init__(self,x, y,color, health = 100):
        super().__init__(x,y, health)
        self.ship_img, self.bullet_img = self.color_map[color]
        self.mask = pygame.mask.from_surface(self.ship_img)
    
    def draw(self, window):
        window.blit(self.ship_img, (self.x + 15, self.y))
        for i in self.bullets:
            i.draw(window)
    def move(self ,movement):
        self.y += movement
#detecting collisions by using masks
def collide(i1,i2):
    offset_x = i2.x - i1.x
    offset_y = i2.y - i1.y
    return i1.mask.overlap(i2.mask, (offset_x, offset_y)) != None
def main():
    global sheild
    global scoree
    on = True
    fps = 70
    level = 0
    lives = 3
    player_movement = 5
    main_font = pygame.font.SysFont('Arial',30)
    lostt_font = pygame.font.SysFont('Arial',40)
    
    
    
    wave_length = 3
    enemy_movement = int(1)
    bullet_movement = 6

    player = Player(500 , 490)

    clock = pygame.time.Clock()

    lostt =  False
    count = 0

    def redraw():
        win.blit(background, (0,0))
        #Texts
        lives_label = main_font.render(f"Lives: {lives}", 1,(255,0,0))
        level_label = main_font.render(f"Level: {level}", 1, (255,0,0))
        sheild_label = main_font.render(f"Shields:{sheild}", 1,(0,0,255))
        score_label = main_font.render(f"Score:{scoree}", 1,(0,225,0))

        win.blit(lives_label, (10,10))
        win.blit(level_label, (width - level_label.get_width() - 10, 10))
        win.blit(sheild_label,(((width - level_label.get_width())/2)-15, hight-40))
        win.blit(score_label, (10,10+20))
   
        for enemy in enemies:
            enemy.draw(win)
        for i in all_meteor:
            i.boundary()
            i.draw(win)
            i.update()
        for i in all_powerups:
            i.draw(win)
            i.update() 

        for i in all_score:
            i.draw(win)
            i.update()

        player.draw(win)
       
            

        #if player.health <= 0 and lives < 0:
            


            #end()

        pygame.display.update()

    while on:
        clock.tick(fps)
        def end():
            lostt_label = lostt_font.render('You Lost !!', 1 ,(255,255,255))
            win.blit(lostt_label, (width/2 - lostt_label.get_width()/2, 350))
            main_menu2()

        if player.health < 0 and lives > 0:
            lives -=1
            player.increasehealth()
        elif player.health <0 and lives <= 0:
            end()
        
            #count += 1
            #lostt = True

        #if lostt == True:)
            #win.blit(lostt_label, (width/2 - lostt_label.get_width()/2, 350))
            #lostt_label = lostt_font.render('You Lost !!', 1 ,(255,255,255)

        

        if len(enemies) == 0:
            level = level + 1
            player_movement = 5
            player.bullet_img = bullet
            player.cool_down = 1
            scoree += 250
            
            wave_length = wave_length + 5
            for i in range(int(wave_length)*2):
                enemycurrent = Enemy(random.randrange(100, width - 100), random.randrange(-1500,-110), random.choice(['red','blue','green']))
                enemies.append(enemycurrent)
            for i in range(wave_length + 20):
                m = Meteor()
                all_meteor.append(m)     
            for i in range((int(wave_length/2)) - 2):
                u = powerup()
                all_powerups.append(u)
            for i in range((int(wave_length/2)) - 5):
                s = score()
                all_score.append(s)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                on = False
        keys = pygame.key.get_pressed()
        #Moving Ship
        if (keys[pygame.K_a] or keys[pygame.K_LEFT]) and player.x - player_movement > 0:
            player.x -= player_movement
        if (keys[pygame.K_d]or keys[pygame.K_RIGHT])  and player.x + player_movement + player.get_width() < width:
            player.x += player_movement
        if (keys[pygame.K_w] or keys[pygame.K_UP]) and player.y - player_movement > 0:
            player.y -= player_movement
        if (keys[pygame.K_s] or keys[pygame.K_DOWN]) and player.y + player_movement + player.get_hight() < hight:
            player.y += player_movement
        if (keys[pygame.K_SPACE]):
            
            player.shoot()

        if(keys[pygame.K_LSHIFT]):
            player_movement = 7
        if not keys[pygame.K_LSHIFT]:
            player_movement = 5


        for ene in enemies[:]:
            ene.move(enemy_movement)
            ene.move_bullets(bullet_movement, player)

            if random.randrange(0, 3*50) == 1:
                ene.shoot()

            if collide(ene, player):
                if sheild > 0:
                    sheild -=1
                else:
                    player.health -=10
                hurt_sound.play()
              
                enemies.remove(ene)
                destroy_sound.play()

            elif ene.y + ene.get_hight() > hight:
                player.reducehealth()
               
                enemies.remove(ene)
                destroy_sound.play()
      
        for i in all_meteor[:]:
            if collide(i, player):
                if sheild > 0:
                    sheild -=1
                else:
                    player.health -= 10
                all_meteor.remove(i)
                hurt_sound.play()

        for i in all_powerups[:]:
            if collide(i, player):
                if i.r == 1:
                    sheild +=1
                elif i.r == 2:
                    bullet_movement += 1
                    
                else:
                    player.increasehealth()
                all_powerups.remove(i)
        for i in all_score[:]:
            if collide(i, player):
                scoree +=100
                all_score.remove(i)
        player.move_bullets(-bullet_movement, enemies)
        player.move_bullets(-bullet_movement, all_meteor)


        
        redraw()

 

def main_menu():
    title_font = pygame.font.SysFont('Arial',70, 70)
    run = True
    while run:
        win.blit(background, (0,0))
        title_label = title_font.render("Press the mouse to begin...", 1, (255,255,255))
        win.blit(title_label, (width/2 - title_label.get_width()/2, 350))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.K_ESCAPE:
                run=False
                on = False
            if event.type == pygame.QUIT:
                run = False
                on = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                main()
    pygame.quit()

def main_menu2():
    title_font = pygame.font.SysFont('Arial',70, 70)
    run = True
    while run:
        win.blit(background, (0,0))
        title_label = title_font.render("YOU LOSTT !!! No lives left", 50, (255,255,255))
        f = open('highscore','w')
        
        f.write('scoree')
        f.close()
        win.blit(title_label, (width/2 - title_label.get_width()/2, 350))
        

        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.K_ESCAPE:
                run=False
                on = False
            if event.type == pygame.QUIT:
                run = False
                on = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                main()
    pygame.quit()


main_menu()